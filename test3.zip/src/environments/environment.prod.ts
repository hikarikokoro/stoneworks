export const environment = {
  production: true,
  API_BASE_PATH: 'http://stoneworkssolution.ca'
};
